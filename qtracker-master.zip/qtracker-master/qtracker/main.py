"""Main module."""

from qtracker import __version__


def main():
    """Main function"""
    print(__version__)


if __name__ == "__main__":
    main()
