"""init module for evaluation functions"""
from .distribution_plot import DistPlotDisplay

__all__ = [
    "DistPlotDisplay",
]
