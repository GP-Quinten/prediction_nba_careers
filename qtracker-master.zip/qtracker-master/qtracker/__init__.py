"""Top-level package for qtracker."""

__version__ = "0.0.1"
__author__ = "Quinten Health"
__email__ = "p.godbillot@quinten-health.com"
